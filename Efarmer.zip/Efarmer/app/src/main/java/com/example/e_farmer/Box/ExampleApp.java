package com.example.e_farmer.Box;

import android.app.Application;

import com.example.e_farmer.Settings;

public class ExampleApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        Farmer.init(this);

    }

}
