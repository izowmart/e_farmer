package com.example.e_farmer;

public interface IMainActivity {
    void setToolbarTitle(String fragmentTag);
    void inflateFragment(String fragmentTag);
}
